package resources;

import com.aspose.pdf.License;
import java.io.InputStream;

public class LicenseLoader {
    public static void applyAsposePdfLicense() {
        try {
            License license = new License();
            
            // 리소스 폴더에서 라이선스 파일을 읽음
            // 경로를 정확히 설정 (예: 'resources' 폴더에 위치한 파일)
            InputStream licenseStream = LicenseLoader.class
                    .getClassLoader()
                    .getResourceAsStream("Aspose.PDF.Java.lic");  // 경로가 잘못되었으면 수정

            if (licenseStream == null) {
                System.err.println("Aspose PDF 라이선스 파일을 찾을 수 없습니다.");
                return;
            }

            // 라이선스 파일을 적용
            license.setLicense(licenseStream);
            System.out.println("Aspose PDF 라이선스가 정상적으로 적용되었습니다.");
        } catch (Exception e) {
            System.err.println("Aspose PDF 라이선스 적용 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
